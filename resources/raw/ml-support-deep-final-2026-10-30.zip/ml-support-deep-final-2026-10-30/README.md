# Daten-Zuarbeit: vertieft geprüft

**Start: [aktuelle Übergabe und Entscheidungen](audit/README.md).**

Projektabgleich: `33a7847`, 30.10.2026. Enthalten sind die unveränderten Wetter-Rohdaten, unabhängige Prüfungen und der inzwischen erweiterte DFLD-Bestand des Teams.

Der Ordner `weather/` bewahrt das frühere Datenpaket unverändert. Seine älteren Berichte beschreiben damalige Suchergebnisse. Insbesondere die dortige fehlende OD-Historie, der damalige Stand ohne ML-Code und pauschale Aussagen zu unbekannten Böen sind durch `audit/README.md` und die vier vertieften Prüfberichte präzisiert oder überholt.

## Offline prüfen

Python 3.11 oder neuer mit Zeitzonendaten, aus diesem Verzeichnis:

```bash
python3 verify_package.py
python3 weather/verify_package.py
python3 audit/temporal/probe.py --verify
python3 audit/observations/verify_raw_metar.py --source weather/observations --rules weather/reference/rules.json --truth project-data/ground_truth/dfld_hourly.csv --output /tmp/metar-audit-report.json
python3 audit/comparability/analyze_comparability.py --support-package weather --output /tmp/wind-comparison-report.json
python3 audit/labels/audit_labels.py --truth-dir project-data/ground_truth --output /tmp/dfld-audit-report.json
```

`weather/` ist das Wetterpaket. Für eine unveränderte Lieferung die Integrität vor allen Reproduktionen prüfen. Die Skripte schreiben sonst neue Prüfberichte.

Dieses Paket ergänzt die Arbeit des ML-Kollegen. Es enthält keine neu trainierten Modelle, keine geänderte Anwendung und keine neue Modellgütebehauptung. Die bestehenden Trainingsdaten verwenden `best_match`; die zusätzliche Wetterreferenz verwendet `icon_global`.
